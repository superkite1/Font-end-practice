//数值扩展
//新增方法
//方法调整
//2进制   8进制
{
    console.log(0b100);//ES6中二进制的表示法 
    console.log(0o10);//ES6中八进制的表示法
}

{
    console.log(typeof(NaN));//number
    console.log(Number.isFinite());//false
    Number.isFinite(Infinity);  // false
    Number.isFinite(NaN);       // false
    Number.isFinite(-Infinity); // false
    Number.isFinite(0);         // true
    Number.isFinite(2e64);      // true
    Number.isFinite('0');       // false, 全局函数 isFinite('0') 会返回 true
}
{
    console.log(Number.isNaN('radish'));// false
    console.log(Number.isNaN(123));// false
}
{
    console.log(Number.isInteger('radish'));// false
    console.log(Number.isInteger(100));// true
    console.log(Number.isInteger('100'));// false
    console.log(Number.isInteger(100.0000002));// false
}
//-2^53 ~ 2^53
{
    console.log(Number.MAX_SAFE_INTEGER);//9007199254740991
    console.log(Number.MIN_SAFE_INTEGER);//-9007199254740991
    console.log(Number.isSafeInteger(100));//true
    console.log(Number.isSafeInteger('100'));//false
}
//Math
{
    console.log(Math.trunc(4.9));//4  是向下取整
    console.log(Math.floor(4.9));//4  是向下取整
    console.log(Math.ceil(4.9));//5  是向上取整
}
//判断正数还是负数
{
    console.log(Math.sign(100));//1
    console.log(Math.sign(0));//0
    console.log(Math.sign(-100));//-1
    console.log(Math.sign('100'));//-1
    console.log(Math.sign('ab12'));//NaN
}
//立方根
{
    console.log(Math.cbrt(64));//返回的是立方根
}
//三角函数
//对数