//以后开发时放弃传统的array Object  有限说考虑使用Map 如果考虑数据的唯一性使用set
{
    // map和数组的区别
    let map = new Map();
    let array = [];
    // 增
    map.set('t',1);
    array.push({t:1});
    console.log('map-array',map,array);

    //查
    let map_exist = map.has('t');
    let array_exist = array.find(item=>item.t);
    console.log('map-array-find',map_exist,array_exist);
    
    //改
    map.set('t',2);
    array.forEach(item => item.t?item.t=2:'');
    console.log('map-array-modify',map_exist,array_exist);
    
    //删
    map.delete('t');
    let index = array.findIndex(item=> item.t);
    array.splice(index,1);
    console.log('map-array-delete',map_exist,array_exist);
}
{
    // set和数组的区别
    let set = new Set();
    let array = [];
    // 增
    set.add({t:1});
    array.push({t:1});

    console.log('set-array',set,array);

    //查
    let set_exist = set.has({t:1});
    let array_exist = array.find(item=>item.t);
    console.log('set-array-find',set_exist,array_exist);

    //改
    set.forEach(item => item.t?item.t=2:'');
    array.forEach(item=>item.t?item.t=3:'');
    console.log('set-array-modify',set,array);
    //删
    set.forEach(item => item.t?set.delete(item):'');
    let index = array.findIndex(item=> item.t);
    array.splice(index,1);
    console.log('set-array-delete',set,array);
}
// Map与Object的对比
{
    let items = {t:1}
    let map = new Map();
    let set = new Set();
    let obj = {};

    //增
    map.set('t',1);
    set.add(items);
    obj['t']=1;
    console.log(map,set,obj);

    //查
    console.info({
        'map_exist':map.has('t'),
        'set_exist':set.has(items),
        'obj_exist':'t' in obj,
    })
    
    //改
    map.set('t',2);
    items.t=2;
    obj['t']=2;
    console.log(map,set,obj);
    
    //删
    map.delete('t');
    set.delete(items);
    delete obj['t'];
    console.log(map,set,obj);

}
// Set与Object的对比
{

}