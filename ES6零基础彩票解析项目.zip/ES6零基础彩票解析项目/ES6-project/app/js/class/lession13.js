//Promise 对象用于表示一个异步操作的最终完成 (或失败), 及其结果值.
// {
//     // 成功的回调函数
//     function successCallback(result) {
//         console.log("音频文件创建成功: " + result);
//     }

//     // 失败的回调函数
//     function failureCallback(error) {
//         console.log("音频文件创建失败: " + error);
//     }

//     function createAudioFileAsync(audioSettings, successCallback, failureCallback){
//         const {name} = audioSettings;
//         if(name === 'zhangsan'){
//             successCallback(name);
//         }else{
//             failureCallback();
//         }
//     }
//     const audioSettings = {
//         name:'zhangsan',
//         age:18
//     }
//     createAudioFileAsync(audioSettings, successCallback, failureCallback)
// }
// {
//     new Promise((resolve, reject) => {
//         console.log('初始化');
    
//         resolve();
//     })
//     .then(() => {
//         throw new Error('有哪里不对了');
            
//         console.log('执行「这个」”');
//     })
//     .catch(() => {
//         console.log('执行「那个」');
//     })
//     .then(() => {
//         console.log('执行「这个」，无论前面发生了什么');
//     });
// }
{
    //回调的演示
    // let ajax = function (callback) {
    //     console.log('ajax');
    //     setTimeout(function () {
    //         callback && callback.call();
    //     }, 1000);
    // }
    // ajax(function () {
    //     console.log('1');
    // })
} 
// {
//     let ajax = function(){
//         console.log('执行ajax');
//         return new Promise((resolve,reject)=>{
//             setTimeout(()=>{
//                 resolve();
//             },1000);
//         })
//     }
//     ajax()
//     .then(function(){
//         console.log('执行成功状态1');
//         return new Promise((resolve,reject)=>{
//             setTimeout(()=>{
//                 resolve();
//             },1000);
//         })
//     })
//     .then(function(){
//         console.log('执行成功状态2');
//     })
// }
{
    let ajax = function(num){
        console.log('执行ajax');
        console.log('num:'+num);
        return new Promise((resolve,reject)=>{
            if(num > 5){
                resolve();
            }else{
                throw Error('num为'+num)
            }    
        })
    }
    ajax(6)
    .then(function(){
        console.log('执行成功状态1');
        return new Promise((resolve,reject)=>{
            setTimeout(()=>{
                resolve();
            },1000);
        })
    })
    .then(function(){
        console.log('执行成功状态2');
    })
    .catch(function(e){
        console.log(e);
    })
}

{
    let div = document.createElement('div');
    div.id = 'mydiv2';
    document.body.appendChild(div);
    //所有图片加载完后添加到页面
    function loadImg(src){
        return new Promise((resolve,reject)=>{
            let img = document.createElement('img');
            img.src = src;
            img.onload = function(){
                resolve(img);
            }
            img.onerror = function(err){
                reject(img);
            }
        })
    }

    function showImg(imgs){
        console.log(imgs);
        if(imgs instanceof Array){
            imgs.forEach(element => {
                document.getElementById('mydiv2').append(element);
            });
        }else{
            document.body.appendChild(imgs);
        }
    }
    //所有的资源准备好之后  才会再下一次的then操作中拿到所有的数据
    Promise.all([
        loadImg('https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1587904365675&di=c8dc815cfd5d73389da1292843b34184&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fforum%2Fw%3D580%2Fsign%3D0f42866278310a55c424defc87444387%2F5c00f8198618367a22c0634c2f738bd4b21ce5ac.jpg'),
        loadImg('https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1587904365670&di=d80e4c603d4344afee6db52405bed344&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fforum%2Fw%3D580%2Fsign%3D969a0fd853e736d158138c00ab514ffc%2Fc8d70c338744ebf834d8253bdef9d72a6159a744.jpg'),
        loadImg('https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1587904365669&di=2528219f328a1c7356a2356784b83a11&imgtype=0&src=http%3A%2F%2Fimg65.zyzhan.com%2F9%2F20170104%2F636191281121780366110.jpg')
    ]).then((imgs)=>{
        showImg(imgs);
    })
}
{
    let div = document.createElement('div');
    div.id = 'mydiv';
    document.body.appendChild(div);
    //所有图片加载完后添加到页面
    function loadImg(src){
        return new Promise((resolve,reject)=>{
            let img = document.createElement('img');
            img.src = src;
            img.onload = function(){
                resolve(img);
            }
            img.onerror = function(err){
                reject(img);
            }
        })
    }

    function showImg(imgs){
        
        console.log(imgs);
        if(imgs instanceof Array){
            imgs.forEach(element => {
                document.body.appendChild(element);
            });
        }else{
            document.getElementById('mydiv').appendChild(imgs);
        }
    }
    //只要有一个条件满足就可以显示到页面上
    Promise.race([
        loadImg('https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1587904365675&di=c8dc815cfd5d73389da1292843b34184&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fforum%2Fw%3D580%2Fsign%3D0f42866278310a55c424defc87444387%2F5c00f8198618367a22c0634c2f738bd4b21ce5ac.jpg'),
        loadImg('https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1587904365670&di=d80e4c603d4344afee6db52405bed344&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fforum%2Fw%3D580%2Fsign%3D969a0fd853e736d158138c00ab514ffc%2Fc8d70c338744ebf834d8253bdef9d72a6159a744.jpg'),
        loadImg('https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1587904365669&di=2528219f328a1c7356a2356784b83a11&imgtype=0&src=http%3A%2F%2Fimg65.zyzhan.com%2F9%2F20170104%2F636191281121780366110.jpg')
    ]).then((imgs)=>{
        showImg(imgs);
    })
}