//Iterator接口与for...of 循环
{
    let str = 'wangdudu';
    let arr = [1,2,3,4,5,6];
    let obj = {
        name:'zhangsan',
        age:18
    }
    let map = new Map();
    map.set('name','zhangsan');
    map.set('age',19);
    console.log(str,arr,obj,map);
    for (const iterator1 of str) {
        console.log(iterator1);
    }
    for (const iterator2 of arr) {
        console.log(iterator2);
    }
    for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
            const element = obj[key];
            console.log(key,element);
        }
    }
    for (const iterator3 of map) {
        console.log(iterator3);
    }

}
{
    //symbol.Iterator
    let str = 'wangdudu';
    let arr = [1,2,3,4,5,6];
    let map = new Map();
    map.set('name','zhangsan');
    map.set('age',19);


    let maps1 = str[Symbol.iterator]();
    console.log(maps1);
    console.log(maps1.next());

    let maps2 = arr[Symbol.iterator]();
    console.log(maps2);
    console.log(maps2.next());

    let maps4 = map[Symbol.iterator]();
    console.log(maps4);
    console.log(maps4.next());
}
{
    let obj = {
        start:[1,2,3,4],
        end:[5,6,7,8],
        [Symbol.iterator](){
            let self = this;
            let index = 0;
            let arr = this.start.concat(self.end);
            let len = arr.length;
            return{
                next(){
                    if(index<len){
                        return{
                            value:arr[index++],
                            done:false
                        }
                    }else{
                        return{
                            value:arr[index++],
                            done:true
                        }
                    }
                }
            }
        }
    }
    console.log(obj);
    for (const iterator of obj) {
        console.log(iterator);
    }
}
{
    //如果遍历的数据集比较复杂  一定要按照上面的操作进行Iterator接口的部署
}