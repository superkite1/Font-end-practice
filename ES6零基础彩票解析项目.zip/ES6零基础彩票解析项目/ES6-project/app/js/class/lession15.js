//生成器对象是由一个 generator function 返回的,并且它符合可迭代协议和迭代器协议。
//返回的是一个iterator
{
    let tell = function* (){
        yield 'a';
        yield 'b';
        yield 'c';
        return 'd'
    }
    let result = tell();
    console.log(tell);
    console.log(result);
    console.log(result.next());
    console.log(result.next());
    console.log(result.next());
    console.log(result.next());
}
{
    let obj = {};
    obj[Symbol.iterator] = function* (){
        yield 'a';
        yield 'b';
        yield 'c';
    }
    console.log(obj);
    
    for (const iterator of obj) {
        console.log(iterator);
    }
}
{
    //状态机
    //  a   b  c  a  b   c····
    let state = function* (){
        while(1){
            yield 'A';
            yield 'B';
            yield 'C';
        }
    }
    let status = state();
    console.log(status.next());//A
    console.log(status.next());//B
    console.log(status.next());//C
    console.log(status.next());//C
}
{
    //状态机
    //  a   b  c  a  b   c····
    //要安装插件
    // let state =async function* (){
    //     while(1){
    //         await 'A';
    //         await 'B';
    //         await 'C';
    //     }
    // }
    // let status = state();
    // console.log(status.next());//A
    // console.log(status.next());//B
    // console.log(status.next());//C
    // console.log(status.next());//C
}
{
    //使用generator作抽奖次数的限制
    let count = 10;
    let btn = document.createElement('button');
    btn.textContent='抽奖'+count;
    btn.id = 'start1';

    let resets = document.createElement('button');
    resets.textContent='重置';
    resets.id = 'reset';

    let draw = function(count){
        btn.textContent='抽奖'+count;
        console.log(`剩余${count}次`);
    }

    let residue = function* (count){
        while(count>0){
            count--;
            yield draw(count);
        }
    }
    document.body.appendChild(btn);
    document.body.appendChild(resets);

    function figure(count){
        let start = residue(count);
        document.getElementById('start1').addEventListener('click',function(){
            start.next();
        },false);
    }
    figure(count);

    document.getElementById('reset').addEventListener('click',function(){
        figure(count);
        draw(count);
    },false);
    
}

{
    //长轮询  因为http是一种无状态的协议所以需要不断的从服务端获取实时的数据
    //websocket浏览器兼容不好
    //启用定时器不断的从服务端获取实时的数据--长轮询
    let ajax = function* (){
        yield new Promise((resolve,reject)=>{
            setTimeout(()=>{
                resolve({code:1})
            },200)
        })
    }
    //服务端请求数据
    let pull = function(){
        let generator = ajax();
        let step = generator.next();
        step.value.then(function(d){
            if(d.code!=0){
                setTimeout(() => {
                    console.log('await');
                    pull();
                }, 1000);
            }else{
                console.log(d);
            }
        })
    }
    pull();
}

{
    let ajax = function* (){
        return new Promise((resolve,reject)=>{
            setTimeout(()=>{
                resolve({code:0})
            },200)
        })
    }
    let pull = function(){
        let generator = ajax();
        let result = generator.next();
        result.value.then(function(d){
            if(d.code!=0){
                setTimeout(() => {
                    pull();
                }, 1000);
            }else{
                console.log(d);
            }
        })
    }
    pull();
}