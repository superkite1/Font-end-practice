//Symbol  提供一个独一无二的值
//Symbol类型唯一合理的用法是用变量存储 symbol的值，然后使用存储的值创建对象属性。
{
    let a1 = Symbol();
    let a2 = Symbol();
    console.log(a1,a2);
    console.log(a1===a2);
    let a3 = Symbol.for('a3');
    let a4 = Symbol.for('a3');
    console.log(a3===a4);
}
{
    let a1 = Symbol.for('apple');
    let obj = {
        [a1]:'apple',
        apple:'apple',
        banana:'banana'
    }
    console.log(obj);//{apple: "apple", banana: "banana", Symbol(apple): "apple"}
    var result = Object.getOwnPropertySymbols(obj);
    console.log(result);
}
{
    let test = {
        name:'zhangsan',
        age:28
    }
    let uni= Symbol();
    test[uni] = function(){};//属性表达式
    console.log(test);
    for (const key in test) {
        if (test.hasOwnProperty(key)) {
            console.log(key,test[key]);
        }
    }
    var result = Object.getOwnPropertySymbols(test);
    console.log(result);
    console.log(Reflect.ownKeys(test));//
    
}