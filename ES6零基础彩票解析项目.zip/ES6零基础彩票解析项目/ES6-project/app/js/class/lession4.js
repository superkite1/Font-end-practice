//字符串扩展
//字符串新增特性 
//unicode表示法
//遍历接口
//模板字符串
//新增方法(10种 其中有比较常用的ES7的提案需要使用babel-polyfill进行兼容)
{
    console.log('a','\u0061','\u{61}');
    console.log('\u20BB7');
    console.log('\u{20BB7}');
    let str = '𠮷';
}
{
    //codepointat
    let str = '𠮷';
    //es5
    console.log(str.length);
    console.log(str.charAt(0));
    console.log(str.charAt(1));
    console.log(str.charCodeAt(0));
    console.log(str.charCodeAt(1));
    
    //es6
    let str1 = '𠮷a';
    console.log(str1.length);
    
    console.log(str1.codePointAt(0));//134071
    console.log(str1.codePointAt(0).toString(16));//20bb7
    console.log(str1.codePointAt(1));//57271
    console.log(str1.codePointAt(2));//97
}
{
    console.log(String.fromCharCode('0x20bb7'));//es5
    console.log(String.fromCodePoint('0x20bb7'));//es6
}
{
    let str = '\u{20bb7}abcd';
    //es5
    for(let i=0;i<str.length;i++){
        console.log('str   '+str[i]);
    }
    //es6遍历字符串
    for(let code of str){
        console.log('code   '+code);
    }
    console.log( 0x20bb7>0xffff);
    console.log(0x20bb7.toString(10));
    console.log(0xffff.toString(10));
}

//api
{
    let str = 'String';
    console.log('includes r',str.includes('r'));
    console.log('includes c',str.includes('c'));
    console.log('startsWith str',str.startsWith('Str'));
    console.log('endsWith g',str.endsWith('g'));
}
{
    let str = 'abc';
    str = str.repeat(2);
    console.log(str);//abcabc
}
//模板字符串   数据+模板
{
    let name = 'radish';
    let info = "It's my life";
    let message = `my name is ${name},I believe is ${info}`;
    console.log(message);
}
//es7的api
//日期  
{
    let Num = '101';
    console.log(Num.padStart(3,'0'));
    console.log('1'.padEnd(3,'0'));
}
//标签模板
{
    // 怎么用  在哪里用
    //1  过两次HTML字符串的时候  防止xsx攻击
    //2  语言不同 一套模板 可以不同的return 拿到想要的东西
    let userInfo = {
        name:'radish',
        info:"It's my life"
    }
    console.log(`My name is ${userInfo.name} I believe ${userInfo.info}`);
    mention`My name is ${userInfo.name} I believe ${userInfo.info}`
    console.log(mention`My name is ${userInfo.name} I believe ${userInfo.info}`);
    
    function mention(a,b,c){
        console.log(arguments);
        console.log(a,b,c);
        return a+b+c
    }
    mention();
}

//raw使用频率不高
{
    console.log(String.raw`Hi\n${1+2}`);
    console.log(`Hi\n${1+2}`);
}