//数组解构赋值
{
    let a,b,c;
    [a,b,c]=[1,2,3]
    console.log(a,b,c);
}
{
    let a,b,rest;
    [a,b,...rest]=[1,2,3,4,5]
    console.log(a,b,'剩余全部:'+rest);
}
//默认值  没有的话就是undefined
{
    let a,b,c;
    [a,b,c=8]=[1,2]
    console.log(a,b,'默认值:'+c);
}
{
    let a,b,c;
    function test(){
        return [1,2,3]
    }
    [a,b,c]=test();
    console.log(a,b,c);
}
{
    let a,b,c;
    function test(){
        return [1,2,3,4]
    }
    [a,,c]=test();
    console.log('只取目标索引:',a,c);
}
{
    let a,b;
    ({a,b}={a:1,b:2})
    console.log('交换之前',a,b);
    [a,b]=[b,a];
    console.log('交换之后',a,b);
}
//对象解构赋值
{
    let a,b;
    ({a,b}={a:1,b:2})
    console.log(a,b);
}
{
    let meteData={
        title:'皇家品质',
        test:[{
            title:'顶级制造',
            exist:true
        }]
    }
    //特别常用  别名
    let {title:ititle,test:[{title:otitle}]}=meteData;
    console.log(ititle,otitle);
}
