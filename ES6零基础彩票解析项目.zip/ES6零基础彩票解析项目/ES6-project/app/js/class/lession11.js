//Proxy和Reflect  
//代理(连接了真实的对象和用户的中间的一个层)
//映射的是Object

//Proxy 对象用于定义基本操作的自定义行为（如属性查找、赋值、枚举、函数调用等）。
{
    let obj = {
        time:'2020-04-22',
        name:'radish',
        _r:123
    }
    // const p = new Proxy(target, handler)
    // target: 
    //  要使用 Proxy 包装的目标对象
    // （可以是任何类型的对象，包括原生数组，函数，甚至另一个代理）。
    //handler:
    //一个通常以函数作为属性的对象，各属性中的函数分别定义了在执行各种操作时代理 p 的行为。
    let monitor = new Proxy(obj,{
        //拦截属性的获取
        get(target,key){
            console.log('进入get');
            return target[key].replace('2020','2022')
        },
        //拦截属性的设置
        Set(target,key,value){
            return target[key]=value;
        },
        //拦截key in object操作
        has(target,key){
            if(key === 'name'){
                return target[key];
            }else{
                return false
            }
        },
        //拦截删除操作
        deleteProperty(target,key){
            if(key.indexOf('_')> -1){
                delete target[key];
                return true
            }else{
                return target[key]
            }
        },
        //拦截Object.keys() Object.getOwnPropertySymbols Object.getOwnPropertyNames
        ownKeys(target){
            return Object.keys(target).filter(item => item!='time');
        }
    });
    console.log('monitor.time '+monitor.time);
    monitor.name = 'wangye'
    console.log('monitor.name '+monitor.name);
    console.log(obj);
    console.log('name' in obj, 'time' in obj);
    console.log('name' in monitor, 'time' in monitor);
    // delete monitor._r;
    // delete monitor.name;
    // delete monitor.time;
    // console.log(obj);
    console.log('ownKeys',Object.keys(monitor));
}
{
    let obj = {
        time:'2020-04-22',
        name:'radish',
        _r:123
    }
    let monitor = new Proxy(obj,{
        //拦截属性的获取
        get(target,key){
            console.log('进入get');
            if(key === 'name'){
                target[key] = 'Tina';
            }
            return target[key].replace('2020','2022')
        },
        //拦截属性的设置
        Set(target,key,value){
            return target[key]=value;
        },
        //拦截key in object操作
        has(target,key){
            if(key === 'name'){
                return target[key];
            }else{
                return false
            }
        },
        //拦截删除操作
        deleteProperty(target,key){
            if(key.indexOf('_')> -1){
                delete target[key];
                return true
            }else{
                return target[key]
            }
        },
        //拦截Object.keys() Object.getOwnPropertySymbols Object.getOwnPropertyNames
        ownKeys(target){
            return Object.keys(target).filter(item => item!='time');
        }
    });
    console.log(Reflect.get(monitor,'time'));
    console.log('Reflect.get(obj,"time")'+Reflect.get(obj,'time'));
    console.log(Reflect.get(monitor,'name'));
    console.log(Reflect.ownKeys(monitor));
    Reflect.set(monitor,'name','guanyu');// set(obj,key,value)
    console.log(obj);
    console.log(Reflect.has(monitor,'name'));
    console.log(Reflect.has(monitor,'time'));
    Reflect.set(obj,'name','zhangsan');
    console.log(obj);
    Reflect.set(monitor,'name','zhangsanlisi');
    console.log(obj);
}

//reflect
//Reflect 是一个内置的对象，它提供拦截 JavaScript 操作的方法。
//这些方法与proxy handlers的方法相同。Reflect不是一个函数对象，因此它是不可构造的。
//reflect不仅可以映射对象  还可以映射代理
{
    function validator(target,validator){
        return new Proxy(target,{
            _validator : validator,
            set(target,key,value){
                if(target.hasOwnProperty(key)){
                    let va = this._validator[key];//拿到验证方法
                    if(!!va(value)){
                        return Reflect.set(target,key,value);
                    }else{
                        throw Error(`不能设置$(key)到$(value)`);
                    }
                }else{
                    throw Error(`${key}不存在`)
                }
            }
        })
    }
    //验证方法
    const personValidators = {
        name(val){
            return typeof val === 'string'
        },
        age(val){
            return typeof val === 'number' && val>18
        }
    }
    class Person{
        constructor(name,age){
            this.name = name;
            this.age = age;
            return validator(this,personValidators);
        }
    }
    let person1 = new Person('zhangsan',15);
    console.log(person1);
    person1.age = 19;
    person1.name = 'radish';
    console.log(person1);
}