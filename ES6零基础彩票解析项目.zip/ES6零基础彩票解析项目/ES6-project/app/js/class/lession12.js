//类和对象
{
    class Parent {
        constructor(name = 'zhangsan') {
            this.name = name;
        }
    }
    let newP = new Parent('wanglaowu');//与构造函数的使用相同  通过new
    console.log('构造函数和实例:', newP);
} 
{
    //继承
    class Parent {
        constructor(name = 'zhangsan') {
            this.name = name;
        }
    }
    class Child extends Parent {
        constructor(){
            super();
        }
    }
    console.log(new Child('lisi'));
} 
{
    //继承传递参数
    class Parent {
        constructor(name = 'zhangsan') {
            this.name = name;
        }
    }
    class Child extends Parent {
        constructor(name = 'wanglaowu'){
            super(name);
            this.type = 'peasant';
        }
    }
    console.log('继承传递参数',new Child());
}
//getter setter
{
    class HumanName{
        constructor(name = 'zhangsan'){
            this.name = name;
        }
        get FullName(){
            console.log(this.name);
            return this.name
        }
        set FullName(val){
            this.name = val;
        }
    }
    let name1 = new HumanName();
    name1.FullName
    name1.FullName='lisi'
    name1.FullName
    // console.log(name1.FullName);
}
//静态方法
{
    class HumanName{
        constructor(name = 'zhangsan'){
            this.name = name;
        }
        static tell(){
            console.log('静态方法叫');
        }
    }
    HumanName.tell();
}
//静态属性
{
    class HumanName{
        constructor(name = 'zhangsan'){
            this.name = name;
        }
    }
    //使用引用数据类型的特性
    HumanName.gender='male';
    console.log(HumanName.gender);
}