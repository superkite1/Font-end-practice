//数组扩展
//Array.from  用来转换成真正的数组
{
    //ES5  
    //1、循环push到新数组 
    //2、使用Array.prototype.slice.call()
    //3、var args = [].slice.call(arguments, 0);
    //4、 var toArray = function (s) {
    //     try {
    //         return Array.prototype.slice.call(s);
    //     } catch (e) {
    //         var arr = [];
    //         for (var i = 0, len = s.length; i < len; i++) {
    //             //arr.push(s[i]);
    //             arr[i] = s[i]; //据说这样比push快
    //         }
    //         return arr;
    //     }
    // }
    
    // ES6
    let p = document.querySelectorAll('p');
    console.log(p);
    let arr = Array.from(p);
    console.log(arr); 
    arr.forEach((item)=>{
        console.log(item.textContent);
    })
    //实现类似于map的用法
    let arr2 = Array.from([1,2,3],function(item){ return item+100})
    console.log(arr2);
}
//Array.of  生成数组
{
    let arr = [8, 9]
    arr = Array.of(1, 2, 3, 4, 5, 6, 7); //把数据放进数组生成新数组
    console.log(arr);
    let empty = Array.of(); //生成空数组
    console.log(empty);
    console.log(Object.prototype.toString.call(empty));
}
//copyWithin 替换数组数据用的 如果需求是替换固定位置固定顺序、固定大小的
{
    console.log('copyWithWithin');
    console.log([1,2,3,4,5].copyWithin(0,3,5));// 4 5 3 4 5
    
}
//find/findIndex  类似于some  满足条件就返回
{
    console.log('find');
    
    console.log([1,2,3,4,5,6].find(function(item){
        return item>2
    }));

    console.log('findIndex');
    
    console.log([1,2,3,4,5,6].findIndex(function(item){
        return item>2
    }));
    
}
//fill  填充数组
{
    let arr = [1,2,3,4,5,6];
    arr.fill(0,0,2);//value start end
    console.log(arr);// 0 0 3 4 5 6 
}
//entires\keys\values
{
    for(const index of ['a','b','c','d','e'].keys()){
        console.log(index);
    }
    for(const value of ['a','b','c','d','e'].values()){
        console.log(value);
    }
    for(const [index,value] of ['a','b','c','d','e'].entries()){
        console.log(index,value);
    }
    // for(const index of [{a:1},{b:1}].keys()){
    //     console.log(index);
    // }
    // for(const value of [{a:1},{b:1}].values()){
    //     console.log(value);
    // }
    // for(const [index,value] of [{a:1},{b:1}].entries()){
    //     console.log(index,value);
    // }
}
//includes
{
    console.log('number includes',[1,2,3,4,5,6].includes(2));
    console.log('number includes',[1,2,3,4,5,6,NaN].includes(NaN));//includes实现了NaN与NaN的比较
}