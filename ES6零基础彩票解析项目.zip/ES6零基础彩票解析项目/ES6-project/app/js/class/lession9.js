//set map 数据结构
// Set 对象允许你存储任何类型的唯一值，无论是原始值或者是对象引用。
//set 用法
{
    //不重复
    let list = new Set();
    //add
    list.add(1);
    list.add(2);
    list.add(3);
    list.add(3);
    //has
    var result = list.has(3);
    console.log(result);
    console.log(list);
    console.log(list.size);
    //delete
    list.delete(2)
    console.log(list);
    //clear
    list.clear();
    console.log(list);
    //遍历
    let list2 = [1,2,3,4,5,6,7,8,9];
    for(let item of list2){
        console.log(item);//值
    }
    for(let item of list2.keys()){
        console.log(item);//下标
    }
    for(let item of list2.values()){
        console.log(item);//值
    }
    for(let [item,index] of list2.entries()){
        console.log(item,index);//下标 + 值
    }
}
//WeakSet的用法 WeakSet的元素只能是对象
// WeakSet 对象是一些对象值的集合, 并且其中的每个对象值都只能出现一次。在WeakSet的集合中是唯一的
// 它和 Set 对象的区别有两点:
//1、 与Set相比，WeakSet 只能是对象的集合，而不能是任何类型的任意值。
//2、 WeakSet持弱引用：集合中对象的引用为弱引用。 如果没有其他的对WeakSet中对象的引用，那么这些对象会被当成垃圾回收掉。 
// 这也意味着WeakSet中没有存储当前对象的列表。 正因为这样，WeakSet 是不可枚举的。
{
    var ws = new WeakSet();
    var foo = {};
    var bar = {};

    ws.add(foo);
    ws.add(bar);

    ws.has(foo);    // true
    ws.has(bar);   // true

    ws.delete(foo); // 从set中删除 foo 对象
    ws.has(foo);    // false, foo 对象已经被删除了
    ws.has(bar);    // true, bar 依然存在
}
//Map用法
// Map 对象保存键值对，并且能够记住键的原始插入顺序。任何值(对象或者原始值) 都可以作为一个键或一个值。
{
    let map = new Map();
    let arr = ['123'];
    map.set(arr,456);
    console.log(map,map.get(arr));
}
{
    let myMap = new Map();
    let keyObj = {};
    let keyFunc = function() {};
    let keyString = 'a string';
    
    // 添加键
    myMap.set(keyString, "和键'a string'关联的值");
    myMap.set(keyObj, "和键keyObj关联的值");
    myMap.set(keyFunc, "和键keyFunc关联的值");
    
    myMap.size; // 3
    
    // 读取值
    myMap.get(keyString);    // "和键'a string'关联的值"
    myMap.get(keyObj);       // "和键keyObj关联的值"
    myMap.get(keyFunc);      // "和键keyFunc关联的值"
    
    myMap.get('a string');   // "和键'a string'关联的值"
                            // 因为keyString === 'a string'
    myMap.get({});           // undefined, 因为keyObj !== {}
    myMap.get(function() {}); // undefined, 因为keyFunc !== function () {}
    console.log(myMap);
}
{
    //NaN作为键
    let myMap = new Map();
    myMap.set(NaN, "not a number");

    myMap.get(NaN); // "not a number"

    let otherNaN = Number("foo");
    myMap.get(otherNaN); // "not a number"
}
{
    // for...of遍历map
    let myMap = new Map();
    myMap.set(0, "zero");
    myMap.set(1, "one");
    for (let [key, value] of myMap) {
        console.log(key + " = " + value);
    }
    // 将会显示两个log。一个是"0 = zero"另一个是"1 = one"

    for (let key of myMap.keys()) {
        console.log(key);
    }
    // 将会显示两个log。 一个是 "0" 另一个是 "1"

    for (let value of myMap.values()) {
        console.log(value);
    }
    // 将会显示两个log。 一个是 "zero" 另一个是 "one"

    for (let [key, value] of myMap.entries()) {
        console.log(key + " = " + value);
    }
    // 将会显示两个log。 一个是 "0 = zero" 另一个是 "1 = one"
    // Foreach遍历
    myMap.forEach(function(value, key) {
        console.log(key + " = " + value);
    })
    // 将会显示两个logs。 一个是 "0 = zero" 另一个是 "1 = one"
}
{
    // map与数组的关系
    let kvArray = [["key1", "value1"], ["key2", "value2"]];

    // 使用常规的Map构造函数可以将一个二维键值对数组转换成一个Map对象
    let myMap = new Map(kvArray);

    myMap.get("key1"); // 返回值为 "value1"

    // 使用Array.from函数可以将一个Map对象转换成一个二维键值对数组
    console.log(Array.from(myMap)); // 输出和kvArray相同的数组

    // 更简洁的方法来做如上同样的事情，使用展开运算符
    console.log([...myMap]);

    // 或者在键或者值的迭代器上使用Array.from，进而得到只含有键或者值的数组
    console.log(Array.from(myMap.keys())); // 输出 ["key1", "key2"]
}
{
    // 复制和合并maps
    let original = new Map([
        [1, 'one']
    ]);
    
    let clone = new Map(original);
    
    console.log(clone.get(1)); // one
    console.log(original === clone); // false. 浅比较 不为同一个对象的引用

    let first = new Map([
        [1, 'one'],
        [2, 'two'],
        [3, 'three'],
    ]);
    
    let second = new Map([
        [1, 'uno'],
        [2, 'dos']
    ]);
    
    // 合并两个Map对象时，如果有重复的键值，则后面的会覆盖前面的。
    // 展开运算符本质上是将Map对象转换成数组。
    let merged = new Map([...first, ...second]);
    console.log(merged);
    console.log(merged.get(1)); // uno
    console.log(merged.get(2)); // dos
    console.log(merged.get(3)); // three
}
{
    // map对象也能与数组合并
    let first = new Map([
        [1, 'one'],
        [2, 'two'],
        [3, 'three'],
    ]);
    
    let second = new Map([
        [1, 'uno'],
        [2, 'dos']
    ]);
    
    // Map对象同数组进行合并时，如果有重复的键值，则后面的会覆盖前面的。
    let merged = new Map([...first, ...second, [1, 'eins']]);
    
    console.log(merged.get(1)); // eins
    console.log(merged.get(2)); // dos
    console.log(merged.get(3)); // three
}
//WeakMap的用法
{
    // WeakMap 对象是一组键/值对的集合，其中的键是弱引用的。其键必须是对象，而值可以是任意的。
    // WeakMap 的 key 只能是 Object 类型。 原始数据类型 是不能作为 key 的（比如 Symbol）。
    const wm1 = new WeakMap(),
        wm2 = new WeakMap(),
        wm3 = new WeakMap();
    const o1 = {},
        o2 = function(){},
        o3 = window;

    wm1.set(o1, 37);
    wm1.set(o2, "azerty");
    console.log(wm1);
    wm2.set(o1, o2); // value可以是任意值,包括一个对象或一个函数
    wm2.set(o3, undefined);
    wm2.set(wm1, wm2); // 键和值可以是任意对象,甚至另外一个WeakMap对象

    wm1.get(o2); // "azerty"
    wm2.get(o2); // undefined,wm2中没有o2这个键
    wm2.get(o3); // undefined,值就是undefined

    wm1.has(o2); // true
    wm2.has(o2); // false
    wm2.has(o3); // true (即使值是undefined)

    wm3.set(o1, 37);
    wm3.get(o1); // 37

    wm1.has(o1);   // true
    wm1.delete(o1);
    wm1.has(o1);   // false
    }
{
    // 实现一 个带有 .clear() 方法的类 WeakMap 类
    class ClearableWeakMap {
        constructor(init) {
            this._wm = new WeakMap(init)
        }
        clear() {
            this._wm = new WeakMap()
        }
        delete(k) {
            return this._wm.delete(k)
        }
        get(k) {
            return this._wm.get(k)
        }
        has(k) {
            return this._wm.has(k)
        }
        set(k, v) {
            this._wm.set(k, v)
            return this
        }
    }
}