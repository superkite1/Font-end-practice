//模块化
// export let A=123;
// export function test(){
//     console.log('test');
// }
// export class student{
//     test(){
//         console.log('test');
//     }
// }
let A=123;
function test(){
    console.log('test');
}
class student{
    test(){
        console.log('test');
    }
}
export default{
    A,
    test,
    student
}
