//ES5中声明正则对象的两种构造方式  test返回boolean值  exec返回结果集
{
    let regexp1 = new RegExp('abcd','i');
    let regexp2 = new RegExp(/abcd/i);
    const result1 = regexp1.test('ABCDE');
    const result2 = regexp2.test('ABCDE');
    console.log(result1,result2);
}

//ES6 允许第一个参数是正则表达式的方式  第二个参数可以覆盖之前的参数
{
    let regexp3 = new RegExp(/abcd/ig,'i');
    const result3 = regexp3.test('ABCDE');
    console.log(result3);
}

//y、u修饰符
{
    let str = 'aaa_aa_a';
    let regexp1 = /a+/g;
    let regexp2 = /a+/y;
    console.log(regexp1.sticky,regexp2.sticky);
    console.log('first',regexp1.exec(str),regexp2.exec(str));
    console.log('second',regexp1.exec(str),regexp2.exec(str));
    console.log('third',regexp1.exec(str),regexp2.exec(str));
} 
{
    //unicode 正则处理unicode的特征值
    //如果 字符串中有大于两个字节的字符的unicode字符编码  一定要加u
    console.log('u-1',/^\uD83D/.test('\uD83D\uDC2A'));//true
    console.log('u-2',/^\uD83D/u.test('\uD83D\uDC2A')); //false
    console.log('u-3',/\u{61}/.test('a')); //false
    console.log('u-4',/\u{61}/u.test('a')); //true

    console.log('\u{20BB7}');
    let str = '𠮷';
    console.log('u-5',/^.$/.test(str));//false
    console.log('u-6',/^.$/u.test(str));//true
    console.log('u-7',/𠮷{2}/.test('𠮷𠮷'));//false
    console.log('u-8',/𠮷{2}/u.test('𠮷𠮷'));//true
    // /^.$/只能匹配到0xf 小于两个字节长度的字符 
    //回车符 换行符 行分隔符 段分隔符  加s
}