//对象扩展
//函数新增特性
//简介表示法
//属性表达式  ES7提案
//扩展运算符
//Object新增方法

{
    //简洁表示法
    let o = 1;
    let k = 2;
    let es5 = {
        o:o,
        k:k
    };
    //es6中如果属性跟变量名相同时  致谢一个就可以
    let es6 = {
        o,k
    }
    console.log(es5,es6);
    //{o: 1, k: 2} {o: 1, k: 2}
    let es5_method = {
        hello: function(){
            console.log('helloes5');
        }
    }
    let es6_method = {
        hello(){
            console.log('helloes6');
        }
    }
    es5_method.hello();//helloes5
    es6_method.hello();//helloes6
}
{
    //属性表达式
    let apple = 'banana';
    let es5_obj = {
        apple:'apple',
        banana:'banana'
    }
    let es6_obj = {
        [apple]:'apple'
    }
    console.log(es5_obj,es6_obj);
    // {apple: "apple", banana: "banana"} {banana: "apple"}
}
{
    console.log('字符串',Object.is('abc','abc'),'abc'==='abc');
    console.log('字符串',Object.is([],[]),[]===[]);
    console.log('对象',Object.is({},{}),{}==={});
}
{
    //扩展运算符
    let {a, b, ...c} = {a: 12, b: 13, c: 15, d: 16, e: 17};
    console.log(a); //12
    console.log(b); //13
    console.log(c); //{c: 15, d:16, e: 17}
}