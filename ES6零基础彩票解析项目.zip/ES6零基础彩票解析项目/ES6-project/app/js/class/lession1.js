//ES6之前的作用域  全局作用域+函数作用域
//ES6新增了块级作用域
//暂存死区
//不可重复声明
//const声明的是常量所以必须赋值
//遵循作用域链规则
function test(){
    let a = 1;
    console.log(a);
}
function last(){
    const PI = 3.141592653;
    console.log(PI);
}
test();
last();