//整个彩票项目的总入口文件
import 'babel-polyfill';
import Lottery from './lottery';


const syy = new Lottery();
