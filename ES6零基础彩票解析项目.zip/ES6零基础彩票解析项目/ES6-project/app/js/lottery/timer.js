//定时器模块
class Timer{
    /**
     * 
     * @param {截止时间} end 
     * @param {时间更新的回调} update 
     * @param {倒计时结束回调函数} handle 
     */
    countdown(end,update,handle){
        const now = new Date().getTime();//当前时间
        const self = this;
        //如果倒计时已经结束 
        if(now-end>0){
            handle.call(self);
        }else{
            let last_time = end - now;
            const px_d = 1000*60*60*24;//一天的毫秒数
            const px_h = 1000*60*60;//一小时的毫秒数
            const px_m = 1000*60;//一分钟的毫秒数
            const px_s = 1000;//一秒的毫秒数
            //向下取整 拿到剩余时间的日时分秒
            let d = Math.floor(last_time/px_d);
            let h = Math.floor((last_time-d*px_d)/px_h);
            let m = Math.floor((last_time-d*px_d-h*px_h)/px_m);
            let s = Math.floor((last_time-d*px_d-h*px_h-m*px_m)/px_s);
            // 将日时分秒推入数组
            let r= [];
            if(d>0){
                r.push(`<em>${d}</em>天`);
            }
            if(r.length || (h>0)){
                r.push(`<em>${h}</em>时`);
            }
            if(r.length || (m>0)){
                r.push(`<em>${m}</em>分`);
            }
            if(r.length || (s>0)){
                r.push(`<em>${s}</em>秒`);
            }
            self.last_time = r.join('');
            update.call(self,r.join(''));
            setTimeout(() => {
                self.countdown(end,update,handle);
            }, 1000);
        }
    }
}
export default Timer;