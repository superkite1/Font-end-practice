//三个方法   每个方式实现与服务器的通信
import $ from 'jquery';
class Interface{
    /**
     * {getOmit 获取每期号码的遗漏数据}
     * @param {string} issue {当前期号} 
     * @return {[type]}     [description]
     */
    getOmit(issue){
        let self = this;
        return new Promise((resolve,reject)=>{
            $.ajax({
                url:'/get/omit',
                data:{
                    issue:issue,
                },
                dataType:'json',
                success:function(res){
                    self.setOmit(res.data);
                    resolve.call(self,res);
                },
                error:function(err){
                    reject.call(err);
                }
            })
        })
    }

    /**
     * 获取开奖号码的接口
     * @param {string} issue {当前期号} 
     * @return {[type]}     [description]
     */
    getOpenCode(issue){
        return new Promise((resolve,reject)=>{
            $.ajax({
                url:'/get/opencode',
                data:{
                    issue:issue,
                },
                dataType:'json',
                success:function(res){
                    self.setOpenCode(res.data);
                    resolve.call(self,res);
                },
                error:function(err){
                    reject.call(err);
                }
            })
        })
    }
    
    /**
     * {获取每期号码的状态}
     * @param {String} issue  {起好}
     */
    getState(issue){
        return new Promise((resolve,reject)=>{
            $.ajax({
                url:'/get/state',
                data:{
                    issue:issue,
                },
                dataType:'json',
                success:function(res){
                    resolve.call(self,res);
                },
                error:function(err){
                    reject.call(err);
                }
            })
        })
    }
}

export default Interface;