import gulp from 'gulp';
import gulpif from 'gulp-if';
import concat from 'gulp-concat';
import webpack, { Stats } from 'webpack';
import gulpwebpack from 'webpack-stream';//与gulp结合的
import named from 'vinyl-named';//对文件重命名做标志的
import livereload from 'gulp-livereload';//热更新
import plumber from 'gulp-plumber';//管道拼接
import rename from 'gulp-rename';//文件重命名
import uglify from 'gulp-uglify';//资源压缩
import {log,colors} from 'gulp-util';
import args from './util/args';

gulp.task('scripts',()=>{
    return gulp.src(['app/js/index.js'])
    .pipe(plumber({
        errorHandler:function(){

        }
    }))
    .pipe(named())
    .pipe(gulpwebpack({
        module:{
            loaders:[{
                test:/\.js$/,
                loader:'babel'
            }]
        }
    }),null,(err,status)=>{
        log(`Finished '${colors.cyan('scripts')}'`,Stats.toString({
            chunks:false
        }))
    })
    .pipe(gulp.dest('server/public/js'))//编译好文件的路径
    //进行压缩
    .pipe(rename({
        basename:'cp',
        extname:'.min.js'
    }))
    //压缩配置
    .pipe(uglify({compress:{properties:false},output:{'quote_keys':true}}))
    .pipe(gulp.dest('server/public/js'))//压缩后文件的位置
    .pipe(gulpif(args.watch,livereload()))
})