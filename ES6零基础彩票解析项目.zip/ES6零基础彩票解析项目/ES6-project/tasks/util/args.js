import yargs from 'yargs';
//命令行参数
const args = yargs
//区分开发环境和线上
    .option('production',{
        boolean:true,
        default:false,
        describe:'min all scripts'
    })
    //自动编译
    .option('watch',{
        boolean:true,
        default:false,
        describe:'watch all files'
    })
    //要不要详细输出命令行日志
    .option('verbose',{
        boolean:true,
        default:false,
        describe:'log'
    })
    //运维映射  sourcemap
    .option('sourcemaps',{
        describe:'force the creation of sourcemaps'
    })
    //服务器端口
    .option('port',{
        string:true,
        default:8080,
        describe:'server port'
    })
    //表示命令行输入的内容以字符串进行解析
    .argv

    export default args;