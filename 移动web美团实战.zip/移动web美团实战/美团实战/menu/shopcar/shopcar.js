(function () {
    // 购物车顶部字符串模板
    var itemTopTmpl = '<div class="choose-content hide">' +
        '<div class="content-top">' +
        '<div class="clear-car">清空购物车</div>' +
        '</div>' +
        '</div>';
    // 购物车底部字符串模板
    var itemBottomTmpl = '<div class="bottom-content">' +
        '<div class="shop-icon">' +
        '<div class="dot-num hide"></div>' +
        '</div>' +
        '<div class="price-content">' +
        '<p class="total-price">¥<span class="total-price-span">0</span></p>' +
        '<p class="other-price">另需配送&nbsp;¥<span class="shipping-fee">0</span></p>' +
        '</div>' +
        '<div class="submit-btn">去结算</div>' +
        '</div>';
    var $strTop = $(itemTopTmpl);
    var $strBottom = $(itemBottomTmpl);
    //购物车图标上显示的总商品件数
    function changeDot() {
        var $counts = $strTop.find('.count');
        var total = 0;
        var length = $counts.length;
        for (var i = 0; i < length; i++) {
            total += parseInt($counts[i].innerText);
        }
        if (total > 0) {
            $('.dot-num').show().text(total);
        } else {
            $('.dot-num').hide();
        }
    }
    //购物车按钮添加
    function addClick() {
        $('.shop-bar').on('click', '.shop-icon', function () {
            $('.mask').toggle();
            $strTop.toggle();
        });
        $('.mask').on('click', function () {
            $('.mask').toggle();
            $strTop.toggle();
        });
        $strTop.on('click', '.plus', function (e) {
            var $count = $(e.currentTarget).parent().find('.count');
            $count.text(parseInt($count.text() || '0') + 1);
            var $item = $(e.currentTarget).parents('.choose-item').first();
            var itemData = $item.data('itemData');
            itemData.chooseCount++;
            renderItems();
            //找到当前右侧详情的数据  进行联动 代替鼠标进行点击 进行数据的重新渲染 
            $('.left-item.active').click();
            changeDot();
        })
        $strTop.on('click', '.minus', function (e) {
            var $count = $(e.currentTarget).parent().find('.count');
            if ($count.text() == '0') return; //判断0
            $count.text(parseInt($count.text() || '0') - 1);
            var $item = $(e.currentTarget).parents('.choose-item').first();
            var itemData = $item.data('itemData');
            itemData.chooseCount--;
            renderItems();
            $('.left-item.active').click();
            changeDot();
        })
    }
    //显然购物车对应的商品
    function renderItems() {
        $strTop.find('.choose-item').remove();
        var list = window.food_spu_tags || [];
        var temple = '<div class="choose-item">' +
            '<div class="item-name">$name</div>' +
            '<div class="price">¥<span class="total">$price</span></div>' +
            '<div class="select-ontent">' +
            '<div class="minus"></div>' +
            '<div class="count">$chooseCount</div>' +
            '<div class="plus"></div>' +
            '</div>' +
            '</div>';
        var totalPrice = 0;
        list.forEach(function (item) {
            item.spus.forEach(function (_item) {
                // 如果点了某个菜  进行渲染
                if (_item.chooseCount > 0) {
                    //计算这个菜的总价
                    var price = _item.min_price * _item.chooseCount;
                    //替换模板字符串中要显示数据
                    var row = temple.replace('$name', _item.name)
                        .replace('$price', price)
                        .replace('$chooseCount', _item.chooseCount);
                    //累加所有菜的总价
                    totalPrice += price;
                    //把这个菜转为jquery对象
                    var $row = $(row);
                    //进行数据的挂载 保持数据的一致性
                    $row.data('itemData', _item);
                    //DOM结构的添加
                    $strTop.append($row);
                }
            })
        })
        //将计算的总价进行赋值
        changetotalPrice(totalPrice);
    }
    //清空购物车
    function clearShoopCar(){
        $('.clear-car').on('click',function(){
            //移除购物车选好的商品的DOM结构
            $strTop.find('.choose-item').remove();
            var list = window.food_spu_tags || [];
            list.forEach(function (item) {
                item.spus.forEach(function (_item) {
                    // 进行数据的还原
                    if (_item.chooseCount > 0) {
                        _item.chooseCount = 0;
                        renderItems();
                        $('.left-item.active').click();
                        changetotalPrice(0);
                        changeDot();
                    }
                })
            })
        })
    }
    //配送费的渲染
    function deliveryPrice(str) {
        $strBottom.find('.shipping-fee').text(str);
    }

    function changetotalPrice(str) {
        $strBottom.find('.total-price-span').text(str);
    }

    function init(data) {
        $('.shop-bar').append($strTop);
        $('.shop-bar').append($strBottom);
        addClick();
        clearShoopCar();
    }
    init();
    window.shopBar = {
        renderItems: renderItems,
        deliveryPrice: deliveryPrice,
        changeDot: changeDot
    }
})();