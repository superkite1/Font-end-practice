(function () {
    var itemTempl = '<div class="r-item-content">' +
                        '<img class="item-img" src=$pic_url />' +
                    '$brand' +
                        '<div class="item-info-content">' +
                            '<p class="item-title">$name</p>' +
                            '<div class="item-desc clearfix">' +
                            '<div class="item-score">$wm_poi_score</div>' +
                            '<div class="item-count">月售$monthNum</div>' +
                            '<div class="item-distance">&nbsp;$distance</div>' +
                            '<div class="item-time">$mt_delivery_time&nbsp;|</div>' +
                        '</div>' +
                        '<div class="item-price">' +
                            '<div class="item-pre-price">$min_price_tip</div>' +
                        '</div>' +
                        '<div class="item-others">' +
                            '$others' +
                        '</div>' +
                        '</div>' +
                    '</div>';
    // //渲染类目的数据  进行展示
    var page = 0,
        x = 0,
        y = 8,
        isloading = false;

    function getList() {
        page++;
        isloading = true;
        $.get('../json/homelist.json', function (data) {
            setTimeout(function () {
                var list = data.data.poilist.splice(x, y); //只拿8条数据
                initContentList(list);
                isloading = false;
                x += 8;
                y += 8;
            }, 300);
            // console.log(Object.prototype.toString.call(list));
        })
    }

    function initContentList(list) {
        list.forEach(function (item, index) {
            var str = itemTempl
                .replace('$pic_url', item.pic_url)
                .replace('$name', item.name)
                .replace('$wm_poi_score', new StarScore(item.wm_poi_score).getStars())//加星星
                .replace('$monthNum', getMonthNum(item))
                .replace('$distance', item.distance)
                .replace('$brand', getBrand(item))
                .replace('$mt_delivery_time', item.mt_delivery_time)
                .replace('$min_price_tip', item.min_price_tip)
                .replace('$others', getOthers(item));
            $('.list-wrap').append($(str));
        })
    }
    /**
     * 渲染是否热门标签
     * @param {*} data 
     */
    function getBrand(data) {
        if (data.brand_type) {
            return '<div class="brand brand-pin">品牌</div>';
        } else {
            return '<div class="brand brand-xin">新到</div>';
        }
    }
    /**
     * 渲染月售  如果大于999  返回999+
     * @param {*} data 
     */
    function getMonthNum(data) {
        var MonthNum = data.month_sale_num;
        if (MonthNum > 999) {
            return '999+';
        } else {
            return MonthNum;
        }
    }
    /**
     * 渲染商家活动
     * @param {*} data 
     */
    function getOthers(data) {
        var campaigns = data.discounts2;
        var str = '';
        campaigns.forEach(function (item, index) {
            var _str = '<div class="other-info">' +
                '<img src=$icon_url class="other-tag">' +
                '<p class="other-content one-line">$info</p>' +
                '</div>';
            _str = _str.replace('$icon_url', item.icon_url).replace('$info', item.info);
            str += _str;
        })
        return str;
    }

    function addEvent() {
        window.addEventListener('scroll', function () {
            //滚动高度
            var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            // 视口的高度
            var clientHeight = document.documentElement.clientHeight;
            // body高低
            var scrollHeight = document.body.scrollHeight;
            if ((scrollTop + clientHeight) > scrollHeight - 30) {
                if (page < 3) {
                    if (isloading) {
                        return;
                    }
                    getList();
                } else {
                    $('.loading').text('加载完成')
                }
            }
        })
        //添加菜单页面
        setTimeout(function(){
            $('.r-item-content').first().on('click',function(){
                let i=0;
                window.location.pathname.split('/').forEach( item => {
                    if(item.substring(0,5) == 'index'){
                        i++;
                    }
                })
                if(i == 1){
                    window.location.href = window.location.pathname.replace(/index/g,'menu')+'menu.html';
                }
                window.location.href = window.location.pathname.replace(/index/g,'menu');//跳转的菜单界面
            })
        },1000);
    }

    function init() {
        getList();
        addEvent();
    }

    init();
})();