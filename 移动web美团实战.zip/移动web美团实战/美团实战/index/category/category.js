(function () {
    var itemTempl = '<div class="category-item">' +
                        '<img class="item-icon" src=$url />' +
                        '<p class="item-name">$name</p>' +
                    '</div>';
    //渲染类目的数据  进行展示
    function initCategory() {
        $.get('../json/head.json', function (data) {
            var list = data.data.primary_filter.splice(0,8);
            // console.log(Object.prototype.toString.call(list));
            list.forEach(function(item, index){
                var str = itemTempl
                .replace('$url',item.url)
                .replace('$name',item.name);
                $('.category-content').append($(str));
            })
        })
    }
    //绑定类目的a标签点击事件
    function addClick(){
        $('.category-content').on('click','.category-item',function(){
            console.log($(this).text());
        })
    }
    // DOMNodeInserted
    function init() {
        initCategory();
        // setTimeout(addClick,1000);
        // 在DOM结构加载完成就添加点击事件 不理会 js css等文件
        document.addEventListener('DOMContentLoaded',function(){
            // console.log('DOM加载完毕');
            addClick();
        })
    }

    init();
})();