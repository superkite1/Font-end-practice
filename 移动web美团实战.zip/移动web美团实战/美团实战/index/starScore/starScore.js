(function(){
    //得分模板
    var itemTempl='<div class="star-score clearfix">'+
                        '$starstr'+
                    '</div>';
    

    function _getStars(){
        var _score = this.score.toString();

        var scoreArray = _score.split('.');
        // 一个星星
        var fullstar = parseInt(scoreArray[0]);
        //半个星星
        var halfstar = parseInt(scoreArray[1])>=5? 1:0;
        //没有星星
        var nullstar = 5 - fullstar - halfstar;
        // 总的星星
        var starstr = '';
        for(var i=0;i<fullstar;i++){
            starstr+='<div class="star fullstar"></div>';
        }
        for(var j=0;j<halfstar;j++){
            starstr+='<div class="star halfstar"></div>';
        }
        for(var k=0;k<nullstar;k++){
            starstr+='<div class="star nullstar"></div>';
        }
        return itemTempl.replace('$starstr',starstr);
    }
    //将获取星星的函数挂在window，使其他位置可以找到  new也是在window中查到此函数的
    window.StarScore = function(score){
        this.score = score || '';
        this.getStars = _getStars;
    }
})()