(function () {
    var itemTmpl = '<a class="$key tab-item" href="$src.html">' +
                        '$text' +
                    '</a>';
    function init(){
        var items = [{
                        key:'menu',
                        text:'点菜'
                    },{
                        key:'comment',
                        text:'评价'
                    },{
                        key:'restanurant',
                        text:'商家'
                    }];
        var str='';
        //在替换a标签链接地址时，可以使用 ../$key/$key/.html   使用正则表达式进行替换 /\$key/g
        items.forEach(function(item,index){
            str+=itemTmpl.replace('$text',item.text)
                            .replace('$src',item.key)
                            .replace('$key',item.key);
        });
        // 渲染到脚部
        $('.tab-bar').append($(str));
        //拿到当前页面的url 用于改变脚部a标签的样式
        var arr=window.location.pathname.split('/');
        var page=arr[arr.length-1].replace('.html','');
        $('a.'+page).addClass('active').siblings().removeClass('active');
    }
    init();
})()