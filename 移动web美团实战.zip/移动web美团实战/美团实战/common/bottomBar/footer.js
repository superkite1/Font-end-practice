(function () {
    var itemTmpl = '<a class="$key btn-item" href="$src.html">' +
                        '<div class="tab-icon"></div>' +
                        '<div class="tab-text">$text</div>' +
                    '</a>';
    function init(){
        var items = [{
                        key:'index active',
                        src:'../index/index',
                        text:'首页'
                    },{
                        key:'order',
                        src:'../order/order',
                        text:'订单'
                    },{
                        key:'mine',
                        src:'../mine/mine',
                        text:'我的'
                    }];
        var str='';
        //在替换a标签链接地址时，可以使用 ../$key/$key/.html   使用正则表达式进行替换 /\$key/g
        items.forEach(function(item,index){
            str+=itemTmpl.replace('$key',item.key)
                        .replace('$src',item.src)
                        .replace('$text',item.text);
        });
        // 渲染到脚部
        $('.footerBar').append($(str));
        //拿到当前页面的url 用于改变脚部a标签的样式
        let i=0;
        window.location.pathname.split('/').forEach( item => {
            if(item.substring(0,5) == 'index'){
                i++;
            }
        })
        if(i == 1){
            window.location.pathname += 'index.html';
        }
        var arr=window.location.pathname.split('/');
        var page=arr[arr.length-1].replace('.html','');
        $('a.'+page).addClass('active').siblings().removeClass('active');
    }
    init();
})()