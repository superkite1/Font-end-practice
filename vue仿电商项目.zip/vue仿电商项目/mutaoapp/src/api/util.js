// 函数节流  减少请求次数 滚动条的滚动 鼠标的move 窗口的resize
export const debounce = (func, delay = 200) => {
  let timer = null;

  return function (...args) {
    timer && clearTimeout(timer);
    timer = setTimeout(() => {
      func.apply(this, args);
    }, delay);
  };
};
