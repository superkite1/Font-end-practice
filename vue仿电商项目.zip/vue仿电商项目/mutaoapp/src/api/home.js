import axios from 'axios';
import jsonp from 'assets/js/jsonp.js';
import {
  SUCC_CODE,
  EXPIRE_TIME,
  jsonpOptions
} from './config';

// 打乱数组的顺序
const shuffle = (arr) => {
  const arrLength = arr.length;
  let i = arrLength;
  let rndNum;

  while (i--) {
    if (i !== (rndNum = Math.floor(Math.random() * arrLength))) {
      [arr[i], arr[rndNum]] = [arr[rndNum], arr[i]];
    }
  }
  return arr;
};

export const getHomeSlider = () => {
  // 获取幻灯片数据
  return axios.get('http://www.imooc.com/api/home/slider', {
    timeout: EXPIRE_TIME
  }).then(res => {
    if (res.data.code === SUCC_CODE) {
      // 模拟后端接口中  刷新也买你更新幻灯片的接口
      let sliders = res.data.slider;
      const slider = [sliders[Math.floor(Math.random() * sliders.length)]];
      // filter函数会遍历数组 参数为true的保留  false丢弃
      sliders = shuffle(sliders.filter(() => Math.random() >= 0.5));
      if (sliders.length === 0) {
        sliders = slider;
      }
      return sliders;
    }
    throw new Error('您没有成功获取到数据');
  }).catch(error => {
    console.log(error);
    return [{
      linkUrl: 'https://www.imooc.com',
      picUrl: require('assets/img/404.png')
    }];
  });
};

// 获取热门推荐数据
export const getHomeRecommend = (page = 1, psize = 20) => {
  const url = 'https://ju.taobao.com/json/tg/ajaxGetItemsV2.json';
  const params = {
    page,
    psize,
    type: 0,
    frontCatId: ''
  };
  return jsonp(url, params, jsonpOptions).then(res => {
    if (res.code === '200') {
      return res;
    }
    throw new Error('您没有成功获取到数据');
  }).catch(error => {
    if (error) {
      console.log(error);
    }
    return undefined;
  });
};
