export const SUCC_CODE = 0;

export const EXPIRE_TIME = 10000;

export const HOME_RECOMMEND_PAGE_SIZE = 20;

export const jsonpOptions = {
  param: 'callback',
  timeout: EXPIRE_TIME
};
