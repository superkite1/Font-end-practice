import Vue from 'vue';
import Router from 'vue-router';
// import home from '@/pages/home';
// import category from '@/pages/category';
// import cart from '@/pages/cart';
// import personal from '@/pages/personal';
// import search from '@/pages/search';
// import product from '@/pages/product';
Vue.use(Router);

export default new Router({
  routes: [
    {
      path: '*',
      redirect: '/home'
    }, {
      path: '/home',
      name: 'home',
      component: () => import('pages/home'),
      children: [
        {
          path: 'product/:id',
          name: 'home-product',
          component: () => import('pages/product')
        }
      ]
    }, {
      path: '/category',
      name: 'category',
      component: () => import('pages/category')
    }, {
      path: '/cart',
      name: 'cart',
      component: () => import('pages/cart')
    }, {
      path: '/personal',
      name: 'personal',
      component: () => import('pages/personal')
    }, {
      path: '/search',
      name: 'search',
      component: () => import('pages/search')
    }
  ]
});
