<template>
    <!-- 绑定key可以解决我们loop中自动复制最后一张和第一张导致之后的刷新组件得不到更新造成的bug -->
    <swiper :options="swiperOption" :key="keyId">
        <slot></slot>
        <div class="swiper-pagination" v-if="pagination" slot="pagination"></div>
    </swiper>
</template>
<script>
  import {swiper} from 'vue-awesome-swiper';
  export default {
    name: 'MeSlider',
    data() {
      return {
        keyId: Math.random()
      };
    },
    components: {
      swiper
    },
    props: {
      direction: {
        type: String,
        default: 'horizontal',
        validator(value) {
          return [
            'horizontal',
            'vertical'
          ].indexOf(value) > -1;
        }
      },
      interval: {
        type: Number,
        default: 3000,
        validator(value) {
          return value >= 0;
        }
      },
      // 无限轮播
      loop: {
        type: Boolean,
        default: true
      },
      // 分页器
      pagination: {
        type: Boolean,
        default: true
      },
      // 从slider.vue传过来的幻灯片数据
      sliderData: {
        type: Array,
        default() {
          return [];
        }
      }
    },
    watch: {
      // 监测幻灯片数据
      sliderData(newData) {
        if (newData.length === 0) {
          return;
        }
        this.swiperOption.loop = newData.length === 1 ? false : this.loop;
        console.log('无缝滚动:' + this.swiperOption.loop + '       ' + newData.length);
        this.keyId = Math.random();
      }
    },
    created() {
      this.init();
    },
    methods: {
      init() {
        this.swiperOption = {
          /* 只有一个slide(非loop)swiper会失效 */
          watchOverflow: true,
          direction: this.direction,
          autoplay: this.interval ? {
            delay: this.interval,
            disableOnInteraction: false,
            reverseDirection: false// 反向轮播  最为致命
          } : false,
          sliderPreview: 1, // 容器同时显示几张图片
          loop: this.sliderData.length <= 1 ? false : this.loop, // 如果只有一张图片的话关闭无缝滚动
          pagination: {
            el: this.pagination ? '.swiper-pagination' : null
          }
        };
      }
    }
  };
</script>
<style lang="scss" scoped>
    .swiper-container{
        width: 100%;
        height: 100%;
    }
</style>
