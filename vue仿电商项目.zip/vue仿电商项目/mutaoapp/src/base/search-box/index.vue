<template>
  <div class="mine-search-box-wrapper">
    <i class="iconfont icon-search"></i>
    <!-- 变量需要加冒号: 在header中字符串可以不加冒号: -->
    <!-- ref下载组件上就调用的是组件  卸载DOM元素上获取的就是DOM元素 -->
    <div class="mine-search-box" v-if="fake">{{placeholder}}</div>
    <input
      type="text"
      title="搜索框"
      ref="input"
      :placeholder="placeholder"
      v-model="queryData"
      v-if="!fake"
    >
    <!-- 给关闭图标添加事件、显示隐藏 -->
    <i
      class="iconfont icon-close"
      @click="reset"
      v-show="queryData"
    ></i>
  </div>
</template>

<script>
  import {debounce} from 'assets/js/util';// 节流函数
  export default {
    name: 'MeSearchBox',
    data() {
      return {
        queryData: ''
      };
    },
    // 接收从header传过来的参数
    props: {
      placeholder: {
        type: String,
        default: '请输入搜索内容'
      },
      fake: {
        type: Boolean,
        default: false
      }
    },
    // 监听的数据发生较多变化影响性能时、可以通过节流函数减少请求次数、建请服务器的压力
    watch: {
      queryData: debounce(function () {
        this.$emit('query', this.queryData);
      })
    },
    methods: {
      // 获取input焦点
      focus() {
        this.$refs.input && this.$refs.input.focus();
      },
      // 清除input中的内容
      clear() {
        this.queryData = '';
      },
      // 清空输入框
      reset() {
        this.clear();
        this.focus();
      }
    }
  };
</script>

<style lang="scss" scoped>
  @import "~assets/scss/mixins";

  $search-box-height: 30px;

  .mine-search-box-wrapper {
    display: flex;
    align-items: center;
    width: 100%;
    height: $search-box-height;
    padding: 0 7px;
    background-color: #fff;
    border-radius: $search-box-height / 2;
    input{
      flex: 1;
      background: none;
      border: none;
      margin: 0 6px;
      color: #666;
      line-height: 1.5;
    }
  }

  .iconfont {
    color: $icon-color;
    font-size: $icon-font-size-sm;
    font-weight: bold;
  }

  .mine-search-box {
    flex: 1;
    background: none;
    border: none;
    margin: 0 6px;
    color: #666;
    line-height: 1.5;
  }
</style>
