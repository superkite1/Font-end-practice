<template>
    <div class="mine-navbar">
        <div class="mine-navbar-left" v-if="$slots.left">
            <slot name="left">left</slot>
        </div>
        <div class="mine-navbar-center" v-if="$slots.center">
            <slot name="center">center</slot>
        </div>
        <div class="mine-navbar-right" v-if="$slots.right">
            <slot name="right">right</slot>
        </div>
        <h1 class="mine-navbar-title" v-if="title">
            <span class="mine-navbar-text" v-text="title"></span>
        </h1>
    </div>
</template>
<script>
  export default {
    name: 'MeNavbar',
    data() {
      return {

      };
    },
    props: {
      title: {
        type: String,
        defaule: 'hello world'
      }
    }
  };
</script>
<style lang="scss" scoped>
    @import "~assets/scss/mixins";
    .mine-navbar{
        position: relative;
        @include flex-center();
        height: 50px;
        background-color: #fff;
        &-left{
            margin-left: 10px;
            // 如果能找到兄弟节点中有这个类 恢复正常布局
            ~ .mine-navbar-right{
                position: static;
            }
        }
        &-center{
            flex: 1;
            margin: 0 10px;/*居中左右外边距相隔10px距离*/
            // 如果能找到兄弟节点中有这个类 恢复正常布局
            ~ .mine-navbar-right{
                position: static;
            }
        }
        &-right{
            position: absolute;
            right: 0;
            height: 100%;
            @include flex-center();
            margin-right: 10px;
        }
        &-title{
            position: absolute;
            top: 0;
            bottom: 0;
            left: 30%;
            right: 30%;
            @include flex-center();
        }
        &-text{
            padding-left: 2px;
            line-height: 1.5;
            font-size: 18px;
            @include ellipsis();
        }
    }
</style>
