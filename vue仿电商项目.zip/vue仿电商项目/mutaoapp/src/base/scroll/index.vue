<!--滚动组件-->
<template>
    <swiper :options="swiperOption" ref="swiper">
      <div class="mine-scsroll-pull-down" v-if="pullDown">
        <me-loading :text="pullDownText" inline ref="pullDownLoading"></me-loading>
      </div>
      <swiper-slide>
          <slot></slot>
      </swiper-slide>
      <div class="mine-scsroll-pull-up" v-if="pullUp">
        <me-loading :text="pullUpText" inline ref="pullUpLoading"></me-loading>
      </div>
      <div class="swiper-scrollbar" v-if="scrollbar" slot="scrollbar"></div>
    </swiper>
</template>
<script>
  import {swiper, swiperSlide} from 'vue-awesome-swiper';
  import MeLoading from 'base/loading';
  import {
    PULL_DOWN_HEIGHT,
    PULL_DOWN_TEXT_INIT,
    PULL_DOWN_TEXT_START,
    PULL_DOWN_TEXT_ING,
    PULL_DOWN_TEXT_END,
    PULL_UP_HEIGHT,
    PULL_UP_TEXT_INIT,
    PULL_UP_TEXT_START,
    PULL_UP_TEXT_ING,
    PULL_UP_TEXT_END
  } from './config.js';
  export default {
    components: {
      swiper, swiperSlide, MeLoading
    },
    props: {
      scrollbar: {
        type: Boolean,
        default: true
      },
      pullDown: {
        type: Boolean,
        default: false
      },
      pullUp: {
        type: Boolean,
        default: false
      },
      // 从home页面传过来的数据
      data: {
        type: [Array, Object]
      }
    },
    watch: {
      // 当监测到热卖推荐数据改变  进行滚动条的更新 使组件正常工作
      data() {
        this.update();
      }
    },
    created() {
      this.init();
    },
    methods: {
      update() {
        // 保证我们页面的DOM渲染完毕后进行更新操作
        this.$nextTick(() => {
          this.$refs.swiper && this.$refs.swiper.swiper.update();
        });
      },
      // 点击返回顶部组件触发是事件  使用组件自带的api
      scrolltoTop(speed, runCallbacks) {
        this.$refs.swiper && this.$refs.swiper.swiper.slideTo(0, speed, runCallbacks);
      },
      init() {
        this.pulling = false;
        this.pullDownText = PULL_DOWN_TEXT_INIT;
        this.pullUpText = PULL_UP_TEXT_INIT;
        this.swiperOption = {
          direction: 'vertical',
          slidesPerView: 'auto',
          freeMode: true,
          setWrapperSize: true,
          scrollbar: {
            el: this.scrollbar ? '.swiper-scrollbar' : null,
            hide: true
          },
          // 使用swiper的事件api
          on: {
            sliderMove: this.scroll,
            touchEnd: this.touchEnd,
            transitionEnd: this.scrollEnd
          }
        };
      },
      // 手指拖动页面事件
      scroll() {
        // 获取到swiper对象  用来获取上滑下拉的高度
        const swiper = this.$refs.swiper.swiper;
        this.$emit('scroll', swiper.translate, this.$refs.swiper.swiper);
        if (this.pulling) {
          return;
        }
        if (swiper.translate > 0) {
          if (!this.pullDown) {
            return;
          }
          // 在限制的指定位置进行文字的改变
          if (swiper.translate > PULL_DOWN_HEIGHT) {
            this.$refs.pullDownLoading.setText(PULL_DOWN_TEXT_START);
          } else {
            this.$refs.pullDownLoading.setText(PULL_DOWN_TEXT_INIT);
          }
        } else if (swiper.isEnd) { // 上拉
          if (!this.pullUp) {
            return;
          }

          const isPullUp = Math.abs(swiper.translate) + swiper.height - PULL_UP_HEIGHT > parseInt(swiper.$wrapperEl.css('height'));

          if (isPullUp) {
            this.$refs.pullUpLoading.setText(PULL_UP_TEXT_START);
          } else {
            this.$refs.pullUpLoading.setText(PULL_UP_TEXT_INIT);
          }
        }
      },
      scrollEnd() {
        // 滚动完成后返回顶部组件
        const swiper = this.$refs.swiper.swiper;
        this.$emit('scroll-end', swiper.translate, swiper, this.pulling);
      },
      // 手指松开就触发的事件
      touchEnd() {
        // 如果为true表示正在拖动
        if (this.pulling) {
          return;
        }
        // 手指松开后  再次拿到swiper对象 这里的swiper为容器对象  包着我们的内容
        const swiper = this.$refs.swiper.swiper;
        if (swiper.translate > PULL_DOWN_HEIGHT) {
          if (!this.pullDown) {
            return;
          }
          this.pulling = true;
          swiper.allowTouchMove = false; // 禁止触摸
          swiper.setTransition(swiper.params.speed);
          swiper.setTranslate(PULL_DOWN_HEIGHT);
          swiper.params.virtualTranslate = true;// 固定 不回弹
          this.$refs.pullDownLoading.setText(PULL_DOWN_TEXT_ING);
          // 手指松开后  将松开后要执行的函数传递给home界面 home界面会运行我们传递的函数
          this.$emit('pull-down', this.pulldownEnd);
        } else if (swiper.isEnd) { // 底部
          const totalHeight = parseInt(swiper.$wrapperEl.css('height'));
          const isPullUp = Math.abs(swiper.translate) + swiper.height - PULL_UP_HEIGHT > totalHeight;
          if (isPullUp) { // 上拉
            if (!this.pullUp) {
              return;
            }
            this.pulling = true;
            swiper.allowTouchMove = false; // 禁止触摸
            swiper.setTransition(swiper.params.speed);
            swiper.setTranslate(-(totalHeight + PULL_UP_HEIGHT - swiper.height));
            swiper.params.virtualTranslate = true; // 定住不给回弹
            this.$refs.pullUpLoading.setText(PULL_UP_TEXT_ING);
            this.$emit('pull-up', this.pullUpEnd);
          }
        }
      },
      // 下拉松手后触发的事件
      pulldownEnd() {
        const swiper = this.$refs.swiper.swiper;
        this.pulling = false;
        this.$refs.pullDownLoading.setText(PULL_DOWN_TEXT_END);// 修改状态
        swiper.params.virtualTranslate = false;// 回弹
        swiper.allowTouchMove = true; // 可以触摸
        swiper.setTransition(swiper.params.speed);// 设置初始速度
        swiper.setTranslate(0);// 回复原位
        setTimeout(() => {
          this.$emit('pull-down-transition-end');
        }, swiper.params.speed);
      },
      // 上滑松手后触发的事件
      pullUpEnd() {
        const swiper = this.$refs.swiper.swiper;
        this.pulling = false;
        this.$refs.pullUpLoading.setText(PULL_UP_TEXT_END);
        swiper.params.virtualTranslate = false;// 固定不让回弹
        swiper.allowTouchMove = true;
      }
    }
  };
</script>
<style lang="scss" scoped>
    .swiper-container{
        overflow: hidden;
        width: 100%;
        height: 100%;
    }
    .swiper-slide{
        height: auto;
    }
    .mine-scsroll-pull-up,
    .mine-scsroll-pull-down{
      position: absolute;
      left: 0;
      width: 100%;
    }
    .mine-scsroll-pull-up{
      top: 100%;
      height: 30px;
    }
    .mine-scsroll-pull-down{
      bottom: 100%;
      height: 80px;
    }
</style>
