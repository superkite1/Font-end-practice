<template>
    <div class="mine-loading" :class="{'mine-loading-inline':inline}">
        <span class="mine-loading-indicator" v-if="indicator === 'on'">
            <slot>
                <img src="./loading.gif" alt="loading">
            </slot>
        </span>
        <span class="mine-loading-text" v-if="loadingText">{{loadingText}}</span>
    </div>
</template>
<script>
  export default {
    name: 'MeLoading',
    data() {
      return {
        loadingText: this.text
      };
    },
    props: {
      indicator: {
        type: String,
        default: 'on',
        validator(value) {
          return ['on', 'off'].indexOf(value) > -1;
        }
      },
      // 使穿过来的文字也可以
      text: {
        type: String,
        default: '加载中···'
      },
      inline: {
        type: Boolean,
        default: true
      }
    },
    watch: {
      text(text) {
        this.loadingText = text;
      }
    },
    methods: {
      // 暴露在外的接口 调用的组件可以调用
      setText(text) {
        this.loadingText = text;
      }
    }
  };
</script>
<style lang="scss" scoped>
    @import "~assets/scss/mixins";
    .mine-loading{
        width: 100%;
        height: 100%;
        overflow: hidden;
        @include flex-center(column);

        &.mine-loading-inline{
            flex-direction: row;
            .mine-loading-indicator ~ .mine-loading-text{
                margin-top:0px;
                margin-left: 6px;
            }
        }
    }
    .mine-loading-indicator ~ .mine-loading-text{
        margin-top:6px;
    }
</style>
