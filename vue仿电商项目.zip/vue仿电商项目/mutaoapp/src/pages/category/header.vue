<template>
  <me-navbar class="header">
    <me-searchbox
        placaholder="开学季有礼、好货五折起"
        slot="center"
        @query='query'
        fake
        @click.native="goToSearch"
    />
    <i class="iconfont icon-msg" slot="right"></i>
  </me-navbar>
</template>
<script>
  import MeNavbar from 'base/navbar';
  import MeSearchbox from '@/base/search-box';
  export default {
    name: 'CategoryHeader',
    components: {
      MeNavbar,
      MeSearchbox
    },
    methods: {
      query(queryData) {
        console.log(queryData);
      },
      goToSearch() {
        this.$router.push('/search');
      }
    }
  };
</script>

<style lang="scss" scoped>
  @import "~assets/scss/mixins";

  .header {
    &.mine-navbar {
      background-color: $header-bgc-translucent;
    }

    .iconfont {
      color: $icon-color-default;
      font-size: $icon-font-size;
    }
    .header-input{
          position: relative;
            &-here{
              width: 100%;
              background-color: white;
              border-radius: 25px;
              padding: 5px 0px;
              text-indent: 25px;
              &::-webkit-input-placeholder{
                color: black;
              }
            }
            &::before{
              content: '';
              display: block;
              width: 20px;
              height: 20px;
              background: url('../../assets/img/search.png');
              background-size: cover;
              position: absolute;
              top: 3px;
              left: 3px;
            }
        }
  }
</style>
