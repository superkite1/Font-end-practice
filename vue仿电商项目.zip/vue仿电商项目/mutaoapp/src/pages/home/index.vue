<template>
  <div class="home">
    <header class="g-header-container">
      <home-header :class="{'header-transition': isHeaderTransition}" ref="header"/>
    </header>
    <!--data传入获得的数据父组件会监测到 pull-down是scroll组件手指松开传递过来的 -->
    <me-scroll
      :data='recommends'
      pullDown pullUp
      @pull-down="pullDownRefresh"
      @pull-down-transition-end="pullDownTransitionEnd"
      @pull-up="pullUpLoadMore"
      @scroll-end="scrollEnd"
      @scroll="scroll"
      ref="scroll">
      <!-- 幻灯片 -->
      <home-slider ref="slider"/>
      <!-- 10个小图标链接 -->
      <home-nav/>
      <!-- 热卖推荐 -->
      <home-recommend @loaded="getRecommends" ref="recommend" />
    </me-scroll>
    <div class="g-backtop-container">
      <me-backtop :visible="isbackToTop" @backtoTop="backtoTop"></me-backtop>
    </div>
    <router-view></router-view>
  </div>
</template>
<script>
  import HomeHeader from './header';// 顶部组件
  import HomeSlider from './slider';// 幻灯片组件
  import MeScroll from 'base/scroll';// 滚动组件
  import MeBacktop from 'base/backtop';// 回到顶部组件
  import HomeNav from './nav';// 10个导航组件
  import HomeRecommend from './recommend';// 热卖推荐组件
  import {HEADER_TRANSITION_HEIGHT} from './config';
  export default {
    name: 'Home',
    data() {
      return {
        isbackToTop: false,
        isHeaderTransition: false,
        recommends: []
      };
    },
    components: {
      HomeHeader,
      MeScroll,
      MeBacktop,
      HomeNav,
      HomeRecommend,
      HomeSlider
    },
    methods: {
      getItem(data) {
        console.log(data);
      },
      updateScroll() {

      },
      scroll(translate) {
        this.changHeaderstatus(translate);
      },
      scrollEnd(translate, swiper, pulling) {
        this.isbackToTop = translate < 0 && -translate > swiper.height;
        if (!pulling) {
          this.changHeaderstatus(translate);
        }
      },
      // 改变header显示状态  参数:距离
      changHeaderstatus(translate) {
        if (translate > 0) {
          this.$refs.header.hide();
          return;
        }
        this.$refs.header.show();
        this.isHeaderTransition = -translate > HEADER_TRANSITION_HEIGHT;
      },
      // 点击回到顶部组件传递过来触发的函数
      backtoTop() {
        this.$refs.scroll && this.$refs.scroll.scrolltoTop();// 使用scroll组件自带的api滚动回顶部
      },
      getRecommends(recommends) {
        this.recommends = recommends;
      },
      // 下拉刷新中手指松开时调用
      pullDownRefresh(end) {
        this.$refs.slider.update().then(end);
        // setTimeout(() => {
        //   console.log('下拉刷新');
        //   end();
        // }, 1000);
      },
      pullUpLoadMore(end) {
        this.$refs.recommend.update().then(end).catch(err => {
          if (err) {
            console.log(err);
          }
          end();
        });
      },
      // 当过渡完成后 触发css动画
      pullDownTransitionEnd() {
        this.$refs.header.show();
      }
    }
  };
</script>
<style lang="scss" scoped>
@import "~assets/scss/mixins";
.home {
  overflow: hidden;
  width: 100%;
  height: 100%;
  background-color: $bgc-theme;
}
</style>
