<template>
    <div class="slider-wrapper">
      <me-loading v-if="sliders.length === 0"></me-loading>
        <!-- data将幻灯片数据进行绑定 -->
        <me-slider
            :sliderData="sliders"
            :direction="direction"
            :loop="loop"
            :interval="interval"
            :pagination="pagination"
            v-else
        >
            <swiper-slide v-for="(item,index) in sliders" :key="index">
            <a :href="item.linkUrl" class="slider-link">
                <img :src="item.picUrl" alt="" class="slider-img">
            </a>
            </swiper-slide>
        </me-slider>
    </div>
</template>
<script>
  import MeSlider from 'base/slider';// 幻灯片组件
  import {swiperSlide} from 'vue-awesome-swiper';// 业务组件
  import {sliderOptions} from './config.js';// 配置的参数
  import {getHomeSlider} from '@/api/home.js';
  import MeLoading from 'base/loading';// 加载组件

  export default {
    name: 'HomeSlider',
    data() {
      return {
        direction: sliderOptions.direction,
        loop: sliderOptions.loop,
        interval: sliderOptions.interval,
        pagination: sliderOptions.pagination,
        autoplayDisableOninteraction: sliderOptions.autoplayDisableOninteraction,
        sliders: []
      };
    },
    components: {
      MeSlider,
      MeLoading,
      swiperSlide
    },
    created() {
      this.getSliders();
    },
    methods: {
      // 提供外部的更新接口
      update() {
        console.log('幻灯片组件更新');
        return this.getSliders();
      },
      // 获取幻灯片数据
      getSliders() {
        return getHomeSlider().then(data => {
          this.sliders = data;
        });
      }
    }
  };
</script>

<style lang="scss" scoped>
  .slider-wrapper {
    height: 183px;
  }

  .slider-link {
    display: block;
  }

  .slider-link,
  .slider-img {
    overflow: hidden;
    width: 100%;
    height: 100%;
  }

</style>
