<!--顶部组件   包括左中右三部分-->
<template>
    <me-navbar class="header" title="" v-show="visible">
        <i class="iconfont icon-scan" slot="left"></i>
        <me-searchbox
            placaholder="开学季有礼、好货五折起"
            slot="center"
            @query='query'
            fake
            @click.native="goToSearch"
        />
        <i class="iconfont icon-msg" slot="right"></i>
    </me-navbar>
</template>
<script>
  import MeNavbar from '@/base/navbar';
  import MeSearchbox from '@/base/search-box';
  export default {
    data() {
      return {
        name: 'HomeHeader',
        visible: true
      };
    },
    components: {
      MeNavbar,
      MeSearchbox
    },
    methods: {
      show() {
        this.visible = true;
      },
      hide() {
        this.visible = false;
      },
      query(queryData) {
        console.log(queryData);
      },
      // 使用replace会少一条搜索记录
      goToSearch() {
        this.$router.push('/search');
      }
    }

  };
</script>
<style lang="scss" scoped>
    @import "~assets/scss/mixins";
    .header{
        &.mine-navbar{
          background-color: transparent;
          transition: background-color 0.34s;
        }
        &.header-transition{
          background-color: $header-bgc-translucent;
        }
        .iconfont{
            color: $icon-color-default;
            font-size: $icon-font-size;
        }
    }
</style>
