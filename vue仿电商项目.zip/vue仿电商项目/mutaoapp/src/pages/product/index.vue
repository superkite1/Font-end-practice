<template>
    <div class="product" v-if="item">
        product
    </div>
</template>
<script>
  export default {
    name: 'Product',
    data() {
      return {
        item: ''
      };
    },
    // 获取点击商品的详细内容
    created() {
      this.item = this.$route.params.item;
      console.log(this.item);
      
    },
    methods: {

    }
  };
</script>
<style lang="scss" scoped>
  @import "~assets/scss/mixins";
  .product {
      overflow: hidden;
      position: absolute;
      top: 0;
      left: 0;
      z-index: $product-z-index;
      width: 100%;
      height: 100%;
      background-color: $bgc-theme;
    }
</style>
