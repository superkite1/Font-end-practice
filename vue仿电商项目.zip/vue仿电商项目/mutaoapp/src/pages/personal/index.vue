<template>
    <div>
        personal
    </div>
</template>
<script>
  export default {
    data() {
      return {

      };
    }
  };
</script>
