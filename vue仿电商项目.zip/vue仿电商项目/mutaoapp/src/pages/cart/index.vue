<template>
    <div>
        cart
    </div>
</template>
<script>
  export default {
    data() {
      return {

      };
    }
  };
</script>
